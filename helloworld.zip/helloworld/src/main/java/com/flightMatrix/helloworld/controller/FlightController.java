package com.flightMatrix.helloworld.controller;

import com.flightMatrix.helloworld.beans.Flight;
import com.flightMatrix.helloworld.beans.Flights;
import com.flightMatrix.helloworld.service.FlightService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RestController
//@Validated
public class FlightController {

    @Autowired
    FlightService flightService;

    @RequestMapping(value = "/flights/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> delete(@PathVariable("id") String id) {
        flightService.removeFromMap(id);
        return new ResponseEntity<>("flight is deleted successsfully", HttpStatus.OK);
    }

    @RequestMapping(value = "/flights/{id}", method = RequestMethod.PUT)
    public ResponseEntity<Object> updateFlights(@PathVariable("id") String id, @RequestBody Flight flight) {
       flightService.removeFromMap(id);
       flightService.addToMap(id, flight);
        return new ResponseEntity<>("flight is updated successsfully", HttpStatus.OK);
    }

    @RequestMapping(value = "/flights", method = RequestMethod.POST)
    public ResponseEntity<Object> createFlights(@RequestBody  Flight flights ) {
        flightService.addToMap(flights.getFlight(), flights);
        return new ResponseEntity<>("flight is created successfully", HttpStatus.CREATED);
    }

    @RequestMapping(value = "/flights", method = RequestMethod.GET)
    public ResponseEntity<Object> getFlights(@RequestParam (required = false) String departureTime) { // add spring or java8 annotation to validate request param
        Collection<Flight> flightList = flightService.getFlightListbyDepartureTime(departureTime);
        Flights flights  = new Flights();
        flights.setFlights(flightList);
        return new ResponseEntity<>(flights, HttpStatus.OK);
    }

}