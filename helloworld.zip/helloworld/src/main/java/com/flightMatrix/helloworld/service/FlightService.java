package com.flightMatrix.helloworld.service;

import com.flightMatrix.helloworld.beans.Flight;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;


@Service
public class FlightService {
    private static List<Flight> productRepo = new ArrayList<>();

    static {

        Flight airCanada = new Flight();
        airCanada.setFlight("Air Canada 8099");
        airCanada.setDeparture("7:30 AM");
        productRepo.add(airCanada);

        Flight unitedAirline = new Flight();
        unitedAirline.setFlight("United Airline 6115");
        unitedAirline.setDeparture("10:30 AM");
        productRepo.add(unitedAirline);

        Flight westJet = new Flight();
        westJet.setFlight("West Jet 6456");
        westJet.setDeparture("12:30 PM");
        productRepo.add(westJet);

        Flight delta = new Flight();
        delta.setFlight("Delta 3833");
        delta.setDeparture("3:00 PM");
        productRepo.add(delta);
    }

    public LocalTime convertStringToTime(String time) {
        LocalTime lTime = LocalTime.parse(time,
                DateTimeFormatter.ofPattern("h:m a"));
        return lTime;
    }


    public void addToMap(String id, Flight flight) {
        flight.setFlight(id);
        productRepo.add(flight);
    }

    public void removeFromMap(String id) {
        productRepo.remove(id);
    }

    public List<Flight> getFlightListbyDepartureTime(String departureTime) {
        List<Flight> flights = new ArrayList<>();


        if (null != departureTime) {
            try {
                departureTime = departureTime.replace("\"", "");
                LocalTime lTime = convertStringToTime(departureTime);
                for (Flight entry : productRepo) {
                    LocalTime startTime = lTime.minusHours(5);
                    LocalTime endTime = lTime.plusHours(5);
                    LocalTime entryTime = convertStringToTime(entry.getDeparture());

                    if (entryTime.isAfter(startTime) && entryTime.isBefore(endTime)) {
                        flights.add(entry);
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return flights;

        }
        System.out.println(productRepo);
        return productRepo;
    }
}

