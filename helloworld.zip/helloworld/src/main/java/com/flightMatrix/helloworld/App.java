package com.flightMatrix.helloworld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@RestController
//@EnableAutoConfiguration
@SpringBootApplication // same as @Configuration @EnableAutoConfiguration @ComponentScan
public class App {

 /*   @RequestMapping("/")
    String home() {
        return "Hello World!";
    }*/

    public static void main(String[] args) {
        SpringApplication.run(App.class, args);
    }

}