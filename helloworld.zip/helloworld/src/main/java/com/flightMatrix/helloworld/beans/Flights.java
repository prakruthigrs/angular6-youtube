package com.flightMatrix.helloworld.beans;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Flights {
    private List<Flight> flights = new ArrayList<Flight>();

    public List<Flight> getFlights() {
        return flights;
    }

    public void setFlights(Collection<Flight> flights) {
        this.flights.addAll(flights);
    }
}
