package com.flightMatrix.helloworld.beans;

import java.util.Objects;

public class Flight {
     private String flight;
     private String departure;

     public String getFlight() {
          return flight;
     }

     public void setFlight(String flight) {
          this.flight = flight;
     }

     public String getDeparture() {
          return departure;
     }

     public void setDeparture(String departure) {
          this.departure = departure;
     }

     @Override
     public boolean equals(Object o) {
          if (this == o) return true;
          if (!(o instanceof Flight)) return false;
          Flight flight = (Flight) o;
          return Objects.equals(flight, flight.flight) &&
                  Objects.equals(departure, flight.departure);
     }

     @Override
     public int hashCode() {
          return Objects.hash(flight, departure);
     }

     @Override
     public String toString() {
          return "Flights{" +
                  "flight='" + flight + '\'' +
                  ", departure='" + departure + '\'' +
                  '}';
     }
}

